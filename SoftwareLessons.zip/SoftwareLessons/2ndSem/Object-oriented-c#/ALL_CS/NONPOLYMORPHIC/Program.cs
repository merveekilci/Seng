﻿using System;

namespace week8
{
    class Program
    {
        static void Main(string[] args)
        {
            C newC = new C();

            newC.printA();
            newC.printB();
        }
    }
}
