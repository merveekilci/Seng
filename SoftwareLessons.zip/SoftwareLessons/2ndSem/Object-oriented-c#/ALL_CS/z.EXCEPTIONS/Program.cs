﻿using System;

namespace week10
{
    class Program
    {
        static void Main(string[] args)
        {
            Operation op1 = new Operation(3, 4, '/');
            op1.printResult();
        }
    }
}
