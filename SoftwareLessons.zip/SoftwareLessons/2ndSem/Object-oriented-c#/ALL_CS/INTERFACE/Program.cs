﻿using System;

namespace INTERFACE
{
    class Program
    {
        static void Main(string[] args)
        {
            derivedClass derived1 = new derivedClass();
            derived1.printData();
        }
    }
}
