﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLASSES
{
    partial class simpleClass
    {
        // a method to write the result on the screen
        public void printResult()
        {
            Console.WriteLine("Your Age is " + mAge);
        }
    }
}
