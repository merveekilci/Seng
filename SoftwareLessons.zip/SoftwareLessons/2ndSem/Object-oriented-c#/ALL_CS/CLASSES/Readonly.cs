﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLASSES
{
    public class Maths
    {
        private const double constPI = 3.14159;

        private readonly int readonlyPI;

        public Maths()
        {
            readonlyPI = 22 / 7;
        }
    }
}
