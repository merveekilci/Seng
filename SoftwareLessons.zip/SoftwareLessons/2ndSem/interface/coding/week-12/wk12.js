function Myfunction(){
    document.getElementById("p1"),innerHTML="Welcome to my first js page";

}
function toCelcius(fahr){
    document.getElementById("cel").innerHTML="";
}