// This is a comment line
#include <stdio.h>

int main()
{
  // Declaration of variables
  int a;
  int s;
  // Get values
  a = 2;
  s = 5;
  // Process the data
  s = a * a;
  
  // Output the data
  printf("a = %d, \t Square = %d\n", a, s);
}
