# Surface calculation project

In this project a C program was coded to calculate surface of a circle
given the radius from keyboard.

The program expects real value (double) from users and prints the
output as real value (double).