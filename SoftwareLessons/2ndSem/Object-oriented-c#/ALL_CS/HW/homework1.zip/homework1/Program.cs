﻿//******************************************************************
//****** STUDENT NAME: Merve KILCI                  ****************
//****** STUDENT ID..: b211202375                   ****************
//******************************************************************


using System;
using System.Collections; //for array list we need to use this library

namespace Con_homework1
{
    class MainClass
    {
        public static void Main(string[] args)
        {

            CRYPT number1 = new CRYPT(); //create an object called number1

            number1.inputNumber();  //with the object of the number1 call the method input number and others
            number1.printEncryptedNumber();
            number1.printDescryptedNumber();
            Console.ReadLine();

        }




    }
    public class CRYPT  //create a class called CRYPT
    {


        private int number; //field
        private ArrayList arList, arList2; //definition of array list
        public int Number; // Number data member and related property 
        public int tempNumber;
        public int tempNumber2;
        public int tempNumber3;
        public int tempNumber4;
        public int firstDigit;
        public int secondDigit;
        public int thirdDigit;
        public int fourthDigit;


        public int value
        {
            set
            {
                if ((value >= 1000) && (value <= 9999))
                    number = value;

                else
                    number = 1000;

            }
            get { return number; }
        }

        public CRYPT() //constructor with no parameter
        { }

        public CRYPT(int Number) //constructor with one parameter

        {
            if ((Number >= 1000) && (Number <= 9999))
                number = Number;
        }

        public int inputNumber() // checks whether value is valid or not


        {
            int checkvalue = 0;
            Console.Write("Please enter a four-digit number:");  //user will enter the number
            string input = Console.ReadLine();
            bool checking = int.TryParse(input, out checkvalue);
            if (!checking)
            {
                Console.WriteLine("Please do not type alphabetic letters.");
            }
            if ((checkvalue >= 1000) && (checkvalue <= 9999))
            {
                Number = checkvalue;

            }
            else
            {
                Console.WriteLine("Please enter a valid number"); //it the value is not valid warn the user 
            }


            return Number;  //and return the number 
        }

        private void encryptNumber()  //method that calculates the encryption of a number 
                                      //because of the encapsulation
                                      //data hiding
        {

            arList = new ArrayList();  //creating an array

            fourthDigit = (Number % 10);   //calculations and we need to define this values 
            thirdDigit = (Number / 10) % 10; //in the properties line 
            secondDigit = (Number / 100) % 10;  //at first find the digits 
            firstDigit = (Number / 1000) % 10;


            firstDigit = (firstDigit + 7) % 10;  //then replace each digit by (the sum of that digit plus 7) modulus 10.
            secondDigit = (secondDigit + 7) % 10;
            thirdDigit = (thirdDigit + 7) % 10;
            fourthDigit = (fourthDigit + 7) % 10;


            //swapping digits of the number that entered from the user 
            int tempNumber;    //swap the first digit with the third, and swap the second digit with the fourth
            tempNumber = firstDigit;
            firstDigit = thirdDigit;
            thirdDigit = tempNumber;

            int tempNumber2;
            tempNumber2 = secondDigit;
            secondDigit = fourthDigit;
            fourthDigit = tempNumber2;


            for (int i = 0; i < arList.Count; i++)
            {

                arList.Add(i);
            }

            arList.Add(firstDigit);   //with the arList we have swapped the digits of the number 
            arList.Add(secondDigit);
            arList.Add(thirdDigit);
            arList.Add(fourthDigit);

        }

        private void descryptNumber()  //inputs the encrypted number and returns the original number
        {
            encryptNumber();
            arList2 = new ArrayList();
            firstDigit = (firstDigit + 3) % 10;  //then replace each digit by (the sum of that digit plus 3) modulus 10.
            secondDigit = (secondDigit + 3) % 10;
            thirdDigit = (thirdDigit + 3) % 10;
            fourthDigit = (fourthDigit + 3) % 10;
            int tempNumber3;
            tempNumber3 = secondDigit;   //we have changed the digits again 
            secondDigit = fourthDigit;  //like the original number 
            fourthDigit = tempNumber3;

            int tempNumber4;

            tempNumber4 = thirdDigit;
            thirdDigit = firstDigit;
            firstDigit = tempNumber4;


            arList2.Add(firstDigit);   //with the arList we have swapped the digits of the number 
            arList2.Add(secondDigit);
            arList2.Add(thirdDigit);
            arList2.Add(fourthDigit);
        }

        public void printEncryptedNumber()   //print the encrypted number 
        {

            encryptNumber();    //calling encrypted number in the same class
                                //because it is private
                                //and we can not call it in the MainClass

            Console.Write("Encrypted Message..........");  //writing encrypted number on the screen
            foreach (int i in arList)  //assign each elements of the arList to i here
                Console.Write(i + "");
            Console.WriteLine();

        }

        public void printDescryptedNumber()  //print descrypted number
        {

            descryptNumber();  //calling private method in the same class 
            Console.Write("Descrypted Message:........"); //writing on the screen 
            foreach (int i in arList2)  //assign each elements of the arList to i here
                Console.Write(i + "");
            Console.WriteLine();

        }
    }
}
