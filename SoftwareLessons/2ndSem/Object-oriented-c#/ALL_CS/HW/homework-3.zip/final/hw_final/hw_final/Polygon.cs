﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw_final
{
    class Polygon
    {

        //Polygon fields
        private Point2D mCenter;
        private double _lenght;
        private double _numberofedges;
        private double mRadius;


        // Polygon access modifiers
        public Point2D center { set => mCenter = value; get => mCenter; }

        public double lenght { set => _lenght = value; get => _lenght; }

        public double numberofedges { set => _numberofedges = value; get => _numberofedges; }

        double radius { set => mRadius = radius; get => mRadius; }

        //Define a constructor setting inital center and radius with random values
        public Polygon(Point2D center, double radius)
        {


            mCenter = new Point2D();

            mCenter = center;
            mRadius = radius;


        }



        public Polygon()
        {
            // to prevent from the following error
            // System.NullReferenceException: 'Object reference not set to an instance of an object.'
            mCenter = new Point2D();

            Random random = new Random();
            mRadius = random.Next(0, 10);

            center.X = random.Next(0, 10);
            center.Y = random.Next(0, 10);

            Random rd2 = new Random();
            double rand_num2 = rd2.Next(0, 10);
            mRadius = rand_num2;




        }

        public void printInformation()
        {
            Console.WriteLine("Center Point Coordinates : (" + mCenter.X + "," + mCenter.Y + ")");
            Console.WriteLine("Radius                   : " + mRadius);
        }


        public void calculateEdgeCoordinates()
        {

            Console.WriteLine("Please enter a length variable of your polygon ");
            int length = Convert.ToInt32(Console.ReadLine());

            //double vertex_x = mRadius * Math.Cos(a);
            // double vertex_y = mRadius * Math.Sin();



        }
    }



}

