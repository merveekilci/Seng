﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hw_final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public double center_x;
        public double center_y;
        public double length;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
            
            Random random = new Random();
           
            center_x=random.Next(0, 10);
            Console.WriteLine(center_x);


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Random rd1 = new Random();
            center_y = rd1.Next(0, 10);
            Console.WriteLine(center_y);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            Random rd2 = new Random();
            length = rd2.Next(0, 10);
            Console.WriteLine(length);
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine("Please enter a number of edges it must be at least 3");
            length = Convert.ToInt32(Console.ReadLine());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Point2D obj = new Point2D();
            Point2D obj1 = new Point2D(1, 2);  //creating an object with random parameters



            obj1.printCoordinates();  //calling functions 
            obj1.calculatePolarCoordinates();
            obj1.printSphericalCoordinates();

            Polygon obj2 = new Polygon();  //create a new object from polygon class


            obj2.printInformation();  //calling function again 

        }
    }
}
