﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw_final
{
    class Point2D
    {
        private double _X;  //private variables and related properties for these variables 
        private double _Y;

        public double X
        {
            set => _X = value;
            get => _X;
        }

        public double Y
        {
            set => _Y = value;
            get => _Y;
        }

        public Point2D()
        {  //creating a default constructor 

        }

        public Point2D(int X, int Y)   //creating a constructor with parameter that calculates random x and y values and we 
        {                              //need to call it from main function 

            Random rd1 = new Random();
            double rand_num1 = rd1.Next(0, 10);
            _X = rand_num1;

            Random rd2 = new Random();
            double rand_num2 = rd2.Next(0, 10);
            _Y = rand_num2;

        }


        public void printCoordinates()  //printing random variables on the screen 
        {

            Console.WriteLine("the value of x " + _X);   //we are using private values 
            Console.WriteLine("the value of y " + _Y);

        }

        public void calculatePolarCoordinates()   // calculating of the polar coordinates 
        {
            double r = Math.Sqrt((_X * _X) + (_Y * _Y));
            // 0/0 exception so we need to use try catch method 

            Console.WriteLine("Polar coordinates:");


            try
            {
                double a = Math.Atan(_Y / _X);
                Console.WriteLine("P(" + r + "," + a + ")");
            }


            catch (DivideByZeroException)
            {
                Console.WriteLine("unvalid value because of the value of 0");
            }


        }

        public void calculateCartesianCoordinates()
        {
            double a = Math.Atan(_Y / _X);  //calculation arctan with Math.Atan so we need to use Math = System.Math; library 
            _Y = _X * Math.Tan(a);
            _X = _Y * Math.Tan(a);//we are making vice verse of converting to polar coordinates
        }

        public void printSphericalCoordinates()   //printing pre-calculated values 
        {
            Console.WriteLine("spherical coordinates of x " + this._X);
            Console.WriteLine("spherical coordinates of y " + this._Y);
        }




    }
}
